# Hotel-Room-Booking-System
Simple Hotel Room Booking System using CodeIgniter

Admin User

Email : email@gmail.com

Password : admin


```Currently under development```
